#!/bin/bash
# Fresh-boot idle reference (10 min, before any bitstream load) + repeatability session_index 3
# (same scope as index 2). Waits until boot + 15.5 min so the board is settled.
cd ~/gos || exit 1
rm -f ~/.done_idx3b
boot=$(date -d "$(uptime -s)" +%s)
target=$((boot + 930))
echo "[idx3b] boot $(uptime -s) UTC; idle reference starts at $(date -u -d @$target +%FT%TZ)"
while [ $(date +%s) -lt $target ]; do sleep 5; done
echo "[idx3b] start $(date -u +%FT%TZ)"
./session.sh 1 --session-index 3 --idle-ref-s 600; rc1=$?
echo "[idx3b] session 1 rc=$rc1 $(date -u +%FT%TZ)"
./session.sh 2 --session-index 3 --steps s2.B3 s2.CPU; rc2=$?
echo "[idx3b] session 2 rc=$rc2 $(date -u +%FT%TZ)"
./session.sh 3 --session-index 3 --host-path fast --steps s3.fcal s3.B1.lenet5 s3.B1.cifar10; rc3=$?
echo "[idx3b] finished rc=$rc1/$rc2/$rc3 $(date -u +%FT%TZ)"
touch ~/.done_idx3b
